@javax.xml.bind.annotation.XmlSchema(namespace = "http://controllers/")
package edu.agh.soa;
